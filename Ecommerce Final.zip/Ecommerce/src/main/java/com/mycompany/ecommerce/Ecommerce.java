package com.mycompany.ecommerce;

public class Ecommerce {

    public static void main(String[] args) {
        
    }
}
